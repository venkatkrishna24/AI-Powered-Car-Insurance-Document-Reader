import os
import requests

def extract_car_info(text):
    GROQ_API_KEY = os.getenv("GROQ_API_KEY")
    headers = {
        "Authorization": f"Bearer {GROQ_API_KEY}",
        "Content-Type": "application/json"
    }

    prompt = f"""
You will be given a car insurance claim report. Extract and return these details:
• Car Name
• Car Model
• Policy Holder
• License Plate
• Damage Location
• Which parts of the car should be inspected based on the damage location?

Report:
{text}
"""

    data = {
        "model": "llama3-70b-8192",
        "messages": [{"role": "user", "content": prompt}]
    }

    response = requests.post("https://api.groq.com/openai/v1/chat/completions", headers=headers, json=data)
    try:
        return response.json()['choices'][0]['message']['content']
    except:
        return "Failed to extract information from the PDF. Please check your API key or input."
